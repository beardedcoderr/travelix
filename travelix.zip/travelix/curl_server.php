<?php

    $data = file_get_contents('php://input');
    $Data= json_decode($data,true);

    echo 'username: '.$Data['username']." and password: ".$Data['password'];
?>