<!DOCTYPE html>
<html lang="en">
<head>
<title>Flights</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Travelix Project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/elements_styles.css">
<link rel="stylesheet" type="text/css" href="styles/elements_responsive.css">
<link rel="stylesheet" type="text/css" href="styles/booking_style.css">
<link rel="stylesheet" type="text/css" href="styles/slick.css">
<link rel="stylesheet" type="text/css" href="styles/jqx.base.css">
<link rel="stylesheet" type="text/css" href="styles/ranger.css">
<link rel="stylesheet" type="text/css" href="styles/font-awesome.min.css">
</head>

<body>

<div class="super_container">
	
	<!-- Header -->

	<?php include('header.php'); ?>

	<!-- Home -->

	<div class="home">
		<div class="home_background parallax-window" data-parallax="scroll" data-image-src="images/elements_background.jpg"></div>
		<div class="home_content">
			<div class="home_title">Flights</div>
		</div>
	</div>

	<!-- Elements -->

	<div class="elements">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="row">
            <div class="col-md-12">
                <div class="bread-crumb animate-reveal">
                    <h2>Flights List</h2>
                    
                </div>
            </div>
            <div class="col-md-3">

                <div class="form_faq_list box_show_faq">
                    <form>
                        <input type="text" placeholder="Type to search...">
                        <button class="search_faq"><i class="fa fa-search"></i></button>
                    </form>
                </div>

                <div class="search-tem white-box animate-reveal">
                    <span> <i class="fa fa-search"></i>
                        1,984 results found.</span>
                </div>
                <div class="form-detail-sidebar">
                    <h4>modify search</h4>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Where are You departing from?" required>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Where would You Like to go?" required>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control"  placeholder="Check In" id="datepicker-headers2"  required/>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control"  placeholder="Check Off" id="datepicker-headers1" required/>
                    </div>

                     <!-- <div class="form-group">
                        <button type="button" class="btn btn-collapse" data-toggle="collapse" data-target="#demo1">Price <span class="pull-right"><i class="fa fa-chevron-down"></i> </span></button>
                        <div id="demo1" class="collapse">
                            <p id="amount"></p>
                            <div id="slider-range"></div>
                            <input type="hidden" id="amount1" name="amount1">
                            <input type="hidden" id="amount2" name="amount2">
                        </div>
                    </div>

                    <div class="form-group">
                        <button type="button" class="btn btn-collapse" data-toggle="collapse" data-target="#demo2">Flight Times <span class="pull-right"><i class="fa fa-chevron-down"></i> </span></button>

                        <div id="demo2" class="collapse">
                            <p id="time"></p>
                            <div id="time-range"></div>
                            <input type="hidden" id="time1" name="amount1">
                            <input type="hidden" id="time2" name="amount2">
                        </div>
                    </div> *-->
                    <div class="form-group">
                        <button type="button" class="btn btn-collapse" data-toggle="collapse" data-target="#demo3">Stops<span class="pull-right"><i class="fa fa-chevron-down"></i> </span></button>

                        <div id="demo3" class="collapse">
                            <div class="checkbox">
                                <label><input type="checkbox" value="1"> 1 Stops</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" value="2"> 2 Stops</label>
                            </div>
                            <div class="checkbox">
                                <label><input type="checkbox" value="*"> Multiple Stops</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="button" class="btn btn-collapse" data-toggle="collapse" data-target="#demo4">Airlines<span class="pull-right"><i class="fa fa-chevron-down"></i> </span></button>

                        <div id="demo4" class="collapse">
                            <select class="select-two">
                                <option selected="selected">PIA</option>
                                <option>Major Airline</option>
                                <option>AMIRATES</option>
                                <option>AIR BLUE</option>
                                <option>SHAHEEN</option>

                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="button" class="btn btn-collapse" data-toggle="collapse" data-target="#demo5">Flight Type<span class="pull-right"><i class="fa fa-chevron-down"></i> </span></button>
                        <div id="demo5" class="collapse">
                            <select class="select-two">
                                <option selected="selected">Business</option>
                                <option>First Class</option>
                                <option>Economy</option>
                            </select>
                        </div>
                    </div>
                    <a href="#" class="btn btn-search-travel btn-block">SEARCH AGAIN</a>

                </div>
            </div>
            <div class="col-md-9 col-xs-12">
                


                <div class="flight_box_detail white-box">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="flight-logo"><img  alt="logo" src="images/flight-logo.png	"></div>
                        </div>
                        <div class="col-md-8">
                            <div class="details-text">
                                <h4> Consequat ante <a href="#" class="btn btn-stop">1 stop</a> <br><small>Oneway flight</small></h4>
                            </div>
                            <div class="details-feature">
                                <ul class="list-inline list-unstyled">
                                    <li><i class="fa fa-wifi"></i></li>
                                    <li><i class="fa fa-music"></i></li>
                                    <li><i class="fa fa-briefcase"></i></li>
                                    <li><i class="fa fa-cutlery"></i></li>
                                </ul>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="LTT">
                                        <span class="skin-clr"> <i class="fa fa-plane"></i> Take off</span><br>
                                        <span class="time">Wed Nov 13, 2013 7:50 Am</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="LTT">
                                        <span class="skin-clr"> <i class="fa fa-plane fa-rotate-90"></i> Landing</span><br>
                                        <span class="time">Wed Nov 13, 2013 7:50 Am</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="LTT no-border">
                                        <span class="skin-clr"> <i class="fa fa-clock-o"></i> Time</span><br>
                                        <span class="time">8 hours, 15 minutes</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="select-sec">
                                <span>AVG/PERSON <br> <span class="pri">$620</span></span>
                                <a href="../flights_details_one/right_sidebar.html" target="_blank" class="btn btn_select">SELECT</a>
                            </div>
                        </div>
                    </div>
                </div>
				
				
				
				<div class="flight_box_detail white-box">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="flight-logo"><img  alt="logo" src="images/flight-logo.png"></div>
                        </div>
                        <div class="col-md-8">
                            <div class="details-text">
                                <h4> Consequat ante <a href="#" class="btn btn-stop">1 stop</a> <br><small>Oneway flight</small></h4>
                            </div>
                            <div class="details-feature">
                                <ul class="list-inline list-unstyled">
                                    <li><i class="fa fa-wifi"></i></li>
                                    <li><i class="fa fa-music"></i></li>
                                    <li><i class="fa fa-briefcase"></i></li>
                                    <li><i class="fa fa-cutlery"></i></li>
                                </ul>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="LTT">
                                        <span class="skin-clr"> <i class="fa fa-plane"></i> Take off</span><br>
                                        <span class="time">Wed Nov 13, 2013 7:50 Am</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="LTT">
                                        <span class="skin-clr"> <i class="fa fa-plane fa-rotate-90"></i> Landing</span><br>
                                        <span class="time">Wed Nov 13, 2013 7:50 Am</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="LTT no-border">
                                        <span class="skin-clr"> <i class="fa fa-clock-o"></i> Time</span><br>
                                        <span class="time">8 hours, 15 minutes</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="select-sec">
                                <span>AVG/PERSON <br> <span class="pri">$620</span></span>
                                <a href="../flights_details_one/right_sidebar.html" target="_blank" class="btn btn_select">SELECT</a>
                            </div>
                        </div>
                    </div>
                </div>
				
				
				<div class="flight_box_detail white-box">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="flight-logo"><img  alt="logo" src="images/flight-logo.png"></div>
                        </div>
                        <div class="col-md-8">
                            <div class="details-text">
                                <h4> Consequat ante <a href="#" class="btn btn-stop">1 stop</a> <br><small>Oneway flight</small></h4>
                            </div>
                            <div class="details-feature">
                                <ul class="list-inline list-unstyled">
                                    <li><i class="fa fa-wifi"></i></li>
                                    <li><i class="fa fa-music"></i></li>
                                    <li><i class="fa fa-briefcase"></i></li>
                                    <li><i class="fa fa-cutlery"></i></li>
                                </ul>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="LTT">
                                        <span class="skin-clr"> <i class="fa fa-plane"></i> Take off</span><br>
                                        <span class="time">Wed Nov 13, 2013 7:50 Am</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="LTT">
                                        <span class="skin-clr"> <i class="fa fa-plane fa-rotate-90"></i> Landing</span><br>
                                        <span class="time">Wed Nov 13, 2013 7:50 Am</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="LTT no-border">
                                        <span class="skin-clr"> <i class="fa fa-clock-o"></i> Time</span><br>
                                        <span class="time">8 hours, 15 minutes</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="select-sec">
                                <span>AVG/PERSON <br> <span class="pri">$620</span></span>
                                <a href="../flights_details_one/right_sidebar.html" target="_blank" class="btn btn_select">SELECT</a>
                            </div>
                        </div>
                    </div>
                </div>
				
				<div class="flight_box_detail white-box">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="flight-logo"><img  alt="logo" src="images/flight-logo.png"></div>
                        </div>
                        <div class="col-md-8">
                            <div class="details-text">
                                <h4> Consequat ante <a href="#" class="btn btn-stop">1 stop</a> <br><small>Oneway flight</small></h4>
                            </div>
                            <div class="details-feature">
                                <ul class="list-inline list-unstyled">
                                    <li><i class="fa fa-wifi"></i></li>
                                    <li><i class="fa fa-music"></i></li>
                                    <li><i class="fa fa-briefcase"></i></li>
                                    <li><i class="fa fa-cutlery"></i></li>
                                </ul>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="LTT">
                                        <span class="skin-clr"> <i class="fa fa-plane"></i> Take off</span><br>
                                        <span class="time">Wed Nov 13, 2013 7:50 Am</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="LTT">
                                        <span class="skin-clr"> <i class="fa fa-plane fa-rotate-90"></i> Landing</span><br>
                                        <span class="time">Wed Nov 13, 2013 7:50 Am</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="LTT no-border">
                                        <span class="skin-clr"> <i class="fa fa-clock-o"></i> Time</span><br>
                                        <span class="time">8 hours, 15 minutes</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="select-sec">
                                <span>AVG/PERSON <br> <span class="pri">$620</span></span>
                                <a href="../flights_details_one/right_sidebar.html" target="_blank" class="btn btn_select">SELECT</a>
                            </div>
                        </div>
                    </div>
                </div>

                
               
                
                <a href="#" class="btn btn-more animate-reveal"> <i class="fa fa-eye"></i>Loading More</a>
                
            </div>
        </div>
				</div>
			</div>
		</div>	
	</div>

	<!-- Footer -->

	<?php include('footer.php'); ?>

</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/scrollreveal.min.js"></script>
<script src="js/ranger.js"></script>
<script src="js/date-picker.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/progressbar/progressbar.min.js"></script>
<script src="plugins/jquery-circle-progress-1.2.2/circle-progress.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/elements_custom.js"></script>

</body>

</html>